# Cache Cam (Android)

Pre-capture video, like Sony's "Cache Rec": the camera is always buffering the last few
seconds, so the saved clip can start BEFORE you tap.

## Modes (above the red button)
- **CACHE**: tap = saves the buffered seconds and keeps recording. Tap the red square to stop.
- **VIDEO**: normal video, starts when you tap.
- **SLO-MO**: the device's fastest frame rate (120 fps or more), timestamps stretched so it
  plays back slowed down. Also saves the seconds before your tap.

## Screen
- Status pill: green = ready, amber = buffer filling, red = recording (REC timer).
- Top bar: quality chip, pre-roll length, quality picker, gallery, help.
- Bottom left: preview rotation override. If the preview ever looks sideways on some device,
  tap it until it looks right. It only changes the preview, never the saved video.
- Gallery: grid of your clips with a built-in player, share and delete.
- Long-press any button for a tooltip. Clips are saved to Movies/CacheCam.

## Build
GitHub Actions (build.yml) or Android Studio, then run on a real device.

## Camera controls
- Pinch anywhere on the preview to zoom (the chip on the left shows the level, tap it to reset).
- Tap the preview to focus and meter there (a ring shows where).
- 🔄 on the left edge switches front / back camera (selfie preview is mirrored, the saved video is not).
- Sound: the mic is buffered with the pre-roll, so the seconds before your tap have audio too.
  🎤 / 🔇 after the quality chip shows whether sound is being recorded. Slo-mo is silent.

## Not included yet
Grid/level overlays, photo mode, mic on/off switch.

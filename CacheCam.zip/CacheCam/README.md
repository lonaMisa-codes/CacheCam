# Cache Cam (Android)

Pre-capture video, like Sony's "Cache Rec": the camera is always buffering the last
3 seconds. Tap the red button and the saved clip starts 3 s *before* the tap, then keeps
recording until you tap again.

## Best quality, per device
On launch the app asks the camera and the hardware video encoders what they can really do,
then picks the best resolution x fps combination (ranked by pixels per second, so 4K120
beats 4K60 beats 1080p60). Tap **Mode** (top right) to choose any other supported mode.
- HEVC is used when available (otherwise H.264); bitrate scales with resolution and fps.
- If a mode is advertised but the device rejects it at runtime, the app marks it unsupported
  and automatically falls back to the next best one.
- 4K120 only appears on phones whose camera driver exposes it to Camera2 (some phones only
  offer it in their own camera app).

## How it works
- Camera2 feeds a MediaCodec encoder (keyframe every 1 s).
- Encoded frames go into an in-memory ring buffer, trimmed on keyframe boundaries,
  so it always holds 3 to 4 s (about 40 MB at 4K120 HEVC).
- On tap, MediaMuxer writes the buffer to a new MP4, then appends live frames.
- Output: Movies/CacheCam in your gallery.

## Build
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Run on a real device (Android 10+). Emulators are unreliable for camera + encoder.

## Known limits
- Video only, no audio. Landscape only, back camera only.
- Pre-roll length is a constant (`preRollUs` in CacheRecorder.kt).
- Phones may throttle or heat up at 4K120 over long recordings.

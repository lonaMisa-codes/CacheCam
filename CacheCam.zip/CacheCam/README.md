# Cache Cam (Android)

Pre-capture video, like Sony's "Cache Rec": the camera is always buffering the last few
seconds. Tap the red button and the saved clip starts BEFORE the tap, then keeps recording
until you tap the red square.

## Using it
- Red circle = tap to save the buffered seconds and start recording.
- Red square + red pulsing border + REC timer = recording. Tap the square to stop.
- Status pill: green = pre-roll ready, amber = buffer still filling, red = recording.
- Top bar: current quality chip, pre-roll length (3/5/10 s), quality picker, help.
- Long-press any button for a tooltip.
- Clips are saved to Movies/CacheCam.

## Quality
On launch the app asks the camera and the hardware video encoders what they can really do.
- **Recommended (default)**: the sharpest 16:9 picture the device can record at up to 60 fps
  and up to 4K. It differs from device to device.
- **Maximum**: the highest pixels-per-second mode (e.g. 4K120 where the phone exposes it).
- Pick anything else from the Quality button. If a mode is rejected at runtime, the app
  falls back to the next best one automatically.

## Orientation
Rotate the device freely. The preview and the saved file are rotated using the camera's
sensor orientation and the screen rotation. Orientation locks while recording so the file
matches what you saw.

## Build
GitHub Actions workflow (see build.yml) or Android Studio (Koala+), then Run on a real device.

## Known limits
- Video only, no audio. Back camera only.
- Phones may throttle or heat up at 4K120 over long recordings.

package com.example.cachecam

import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.Executors

/** Grid of every clip Cache Cam has saved (Movies/CacheCam). Tap a clip to play it. */
class GalleryActivity : Activity() {

    private class Clip(val id: Long, val uri: Uri, val name: String, val durationMs: Long)

    private val clips = ArrayList<Clip>()
    private val pool = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var grid: GridView
    private lateinit var empty: TextView
    private lateinit var titleView: TextView

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = clips.size
        override fun getItem(position: Int): Any = clips[position]
        override fun getItemId(position: Int): Long = clips[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val clip = clips[position]
            val cell = (convertView as? FrameLayout) ?: buildCell()
            val img = cell.getChildAt(0) as ImageView
            val dur = cell.getChildAt(1) as TextView
            img.setImageDrawable(null)
            img.tag = clip.id
            dur.text = fmt(clip.durationMs)
            pool.execute {
                val bmp = try {
                    contentResolver.loadThumbnail(clip.uri, Size(480, 270), null)
                } catch (e: Exception) {
                    null
                }
                if (bmp != null) ui.post { if (img.tag == clip.id) img.setImageBitmap(bmp) }
            }
            cell.setOnClickListener {
                startActivity(
                    Intent(this@GalleryActivity, PlayerActivity::class.java)
                        .putExtra("uri", clip.uri.toString())
                        .putExtra("name", clip.name)
                )
            }
            return cell
        }
    }

    private fun buildCell(): FrameLayout {
        val cell = FrameLayout(this)
        cell.layoutParams = AbsListView.LayoutParams(-1, dpPx(120))
        cell.background = GradientDrawable().apply {
            cornerRadius = dpPx(12).toFloat()
            setColor(0xFF1A1F29.toInt())
        }
        cell.outlineProvider = ViewOutlineProvider.BACKGROUND
        cell.clipToOutline = true
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        cell.addView(img, FrameLayout.LayoutParams(-1, -1))
        val dur = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(dpPx(8), dpPx(3), dpPx(8), dpPx(3))
            background = GradientDrawable().apply {
                cornerRadius = dpPx(10).toFloat()
                setColor(0xAA000000.toInt())
            }
        }
        cell.addView(dur, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dpPx(8), dpPx(8))
        })
        return cell
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0B0E13.toInt())
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpPx(14), dpPx(14), dpPx(14), dpPx(6))
        }
        header.addView(pillChip("←", "Back to the camera") { finish() })
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            text = "Gallery"
            setPadding(dpPx(14), 0, 0, 0)
        }
        header.addView(titleView)
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        grid = GridView(this).apply {
            numColumns = GridView.AUTO_FIT
            columnWidth = dpPx(200)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            horizontalSpacing = dpPx(8)
            verticalSpacing = dpPx(8)
            setPadding(dpPx(12), dpPx(8), dpPx(12), dpPx(12))
            clipToPadding = false
            adapter = this@GalleryActivity.adapter
        }
        empty = TextView(this).apply {
            setTextColor(0xAAFFFFFF.toInt())
            textSize = 15f
            gravity = Gravity.CENTER
            text = "No clips yet.\nTap the red button in the camera to save your first one."
            visibility = View.GONE
        }
        val body = FrameLayout(this)
        body.addView(grid, FrameLayout.LayoutParams(-1, -1))
        body.addView(empty, FrameLayout.LayoutParams(-1, -1))
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    override fun onDestroy() {
        pool.shutdownNow()
        super.onDestroy()
    }

    private fun load() {
        pool.execute {
            val list = ArrayList<Clip>()
            try {
                val proj = arrayOf(
                    MediaStore.Video.Media._ID,
                    MediaStore.Video.Media.DISPLAY_NAME,
                    MediaStore.Video.Media.DURATION,
                )
                contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    proj,
                    "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?",
                    arrayOf("Movies/CacheCam%"),
                    "${MediaStore.Video.Media.DATE_ADDED} DESC",
                )?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                        list.add(Clip(id, uri, c.getString(1) ?: "clip", c.getLong(2)))
                    }
                }
            } catch (_: Exception) {
            }
            ui.post {
                clips.clear()
                clips.addAll(list)
                adapter.notifyDataSetChanged()
                empty.visibility = if (clips.isEmpty()) View.VISIBLE else View.GONE
                titleView.text = "Gallery · ${clips.size} clip" + if (clips.size == 1) "" else "s"
            }
        }
    }
}

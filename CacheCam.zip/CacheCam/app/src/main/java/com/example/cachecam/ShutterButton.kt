package com.example.cachecam

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * Camera-style shutter button.
 * Idle: white ring + solid red circle ("tap to start").
 * Recording: red rounded square ("tap to stop") with a pulsing red halo.
 */
class ShutterButton(context: Context) : View(context) {

    private val red = 0xFFE53935.toInt()
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = red }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = red }

    private var morph = 0f   // 0 = circle, 1 = square
    private var pulse = 0f   // 0..1 repeating while recording
    private var morphAnim: ValueAnimator? = null
    private var pulseAnim: ValueAnimator? = null

    var recording: Boolean = false
        set(value) {
            if (field == value) return
            field = value
            animateMorph(if (value) 1f else 0f)
            if (value) startPulse() else stopPulse()
        }

    init {
        isClickable = true
        isFocusable = true
        contentDescription = "Capture"
    }

    private fun animateMorph(target: Float) {
        morphAnim?.cancel()
        morphAnim = ValueAnimator.ofFloat(morph, target).apply {
            duration = 180
            addUpdateListener { morph = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun startPulse() {
        pulseAnim?.cancel()
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1100
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun stopPulse() {
        pulseAnim?.cancel()
        pulseAnim = null
        pulse = 0f
        invalidate()
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f
        val sw = r * 0.09f

        // Pulsing halo (recording only)
        if (pulse > 0f) {
            halo.strokeWidth = sw
            halo.alpha = ((1f - pulse) * 170).toInt()
            canvas.drawCircle(cx, cy, lerp(r * 0.80f, r - sw, pulse), halo)
        }

        // White outer ring
        ring.strokeWidth = sw
        canvas.drawCircle(cx, cy, r * 0.80f - sw / 2f, ring)

        // Inner shape: circle -> rounded square
        val half = lerp(r * 0.60f, r * 0.30f, morph)
        val corner = lerp(half, r * 0.10f, morph)
        canvas.drawRoundRect(cx - half, cy - half, cx + half, cy + half, corner, corner, fill)
    }

    override fun onDetachedFromWindow() {
        morphAnim?.cancel()
        pulseAnim?.cancel()
        super.onDetachedFromWindow()
    }
}

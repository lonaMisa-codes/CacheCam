package com.example.cachecam

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView

/** Full-screen player for one saved clip, with share and delete. */
class PlayerActivity : Activity() {

    private lateinit var video: VideoView
    private lateinit var uri: Uri
    private var clipName = "Clip"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = intent.getStringExtra("uri")
        if (u == null) {
            finish()
            return
        }
        uri = Uri.parse(u)
        clipName = intent.getStringExtra("name") ?: "Clip"

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        val controller = MediaController(this)
        controller.setAnchorView(video)
        video.setMediaController(controller)
        video.setOnPreparedListener {
            it.isLooping = false
            video.start()
        }
        video.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "Can't play this clip", Toast.LENGTH_LONG).show()
            true
        }
        video.setVideoURI(uri)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpPx(14), dpPx(12), dpPx(14), 0)
        }
        bar.addView(pillChip("←", "Back to the gallery") { finish() })
        val label = TextView(this).apply {
            text = clipName
            setTextColor(0xCCFFFFFF.toInt())
            textSize = 13f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
            setPadding(dpPx(12), 0, dpPx(12), 0)
        }
        bar.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(pillChip("Share", "Send this clip to another app") { share() })
        bar.addView(
            pillChip("Delete", "Delete this clip from your device") { confirmDelete() },
            LinearLayout.LayoutParams(-2, -2).apply { marginStart = dpPx(8) }
        )
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        setContentView(root)
    }

    override fun onPause() {
        if (::video.isInitialized) video.pause()
        super.onPause()
    }

    private fun share() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Share clip"))
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Delete this clip?")
            .setMessage("This removes it from your device.")
            .setPositiveButton("Delete") { _, _ ->
                try {
                    contentResolver.delete(uri, null, null)
                    finish()
                } catch (e: Exception) {
                    Toast.makeText(this, "Android blocked deleting this clip", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

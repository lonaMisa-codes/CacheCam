package com.example.cachecam

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

internal fun Activity.dpPx(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Rounded dark "pill" button used by the gallery and the player. */
internal fun Activity.pillChip(label: String, tip: String? = null, onClick: (() -> Unit)? = null): TextView =
    TextView(this).apply {
        setTextColor(Color.WHITE)
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(dpPx(14), dpPx(9), dpPx(14), dpPx(9))
        background = GradientDrawable().apply {
            cornerRadius = dpPx(22).toFloat()
            setColor(0x99000000.toInt())
        }
        text = label
        if (tip != null) tooltipText = tip
        if (onClick != null) setOnClickListener { onClick() }
    }

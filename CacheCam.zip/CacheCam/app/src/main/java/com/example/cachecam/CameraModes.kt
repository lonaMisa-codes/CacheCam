package com.example.cachecam

import android.hardware.camera2.CameraCharacteristics
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.util.Range
import android.util.Size

/** One concrete way this device can record: resolution, frame rate, session type and encoder. */
data class Mode(
    val size: Size,
    val fps: Int,
    val highSpeed: Boolean,
    val mime: String,
    val codecName: String,
    val bitRate: Int,
    val aeRange: Range<Int>,
) {
    val key: String
        get() = "${size.width}x${size.height}@$fps" + if (highSpeed) "/hs" else ""

    val score: Long
        get() = size.width.toLong() * size.height * fps

    val label: String
        get() {
            val res = when {
                size.width >= 7680 -> "8K"
                size.width >= 3840 -> "4K"
                size.width >= 2560 -> "1440p"
                size.width >= 1920 -> "1080p"
                size.width >= 1280 -> "720p"
                else -> "${size.height}p"
            }
            val codec = if (mime == MediaFormat.MIMETYPE_VIDEO_HEVC) "HEVC" else "H.264"
            val mbps = bitRate / 1_000_000
            return "$res ${fps}fps (${size.width}x${size.height}, $codec, ${mbps} Mbps)" +
                if (highSpeed) " high-speed" else ""
        }
}

/**
 * Works out every resolution/fps combination that BOTH the camera and a hardware video encoder
 * support on this device, best first (ranked by pixels per second, so 4K120 beats 4K60).
 */
object CameraModes {
    private val FPS_CANDIDATES = listOf(240, 120, 60, 30)
    private val MIMES = listOf(MediaFormat.MIMETYPE_VIDEO_HEVC, MediaFormat.MIMETYPE_VIDEO_AVC)

    private class Enc(val name: String, val mime: String, val vc: MediaCodecInfo.VideoCapabilities)

    private fun findEncoder(w: Int, h: Int, fps: Int): Enc? {
        val infos = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .filter { it.isEncoder }
            .sortedBy { if (it.isHardwareAccelerated) 0 else 1 }
        for (mime in MIMES) {
            for (info in infos) {
                if (info.supportedTypes.none { it.equals(mime, true) }) continue
                val vc = try {
                    info.getCapabilitiesForType(mime).videoCapabilities
                } catch (e: IllegalArgumentException) {
                    null
                } ?: continue
                try {
                    if (vc.areSizeAndRateSupported(w, h, fps.toDouble())) return Enc(info.name, mime, vc)
                } catch (e: IllegalArgumentException) {
                    // size not supported by this encoder
                }
            }
        }
        return null
    }

    private fun makeMode(size: Size, fps: Int, hs: Boolean, range: Range<Int>): Mode? {
        val enc = findEncoder(size.width, size.height, fps) ?: return null
        val bpp = if (enc.mime == MediaFormat.MIMETYPE_VIDEO_HEVC) 0.08 else 0.12
        val wanted = (size.width.toDouble() * size.height * fps * bpp).toLong()
        val br = enc.vc.bitrateRange
        val bitRate = wanted.coerceIn(br.lower.toLong(), br.upper.toLong()).toInt()
        return Mode(size, fps, hs, enc.mime, enc.name, bitRate, range)
    }

    fun enumerate(chars: CameraCharacteristics): List<Mode> {
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return emptyList()
        val aeRanges = chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            ?.toList() ?: emptyList()
        val out = LinkedHashMap<String, Mode>()

        // Normal (unconstrained) sessions
        for (size in map.getOutputSizes(MediaCodec::class.java) ?: emptyArray()) {
            if (size.width < 1280) continue
            val minDur = map.getOutputMinFrameDuration(MediaCodec::class.java, size)
            val camFps = if (minDur > 0) (1_000_000_000.0 / minDur + 0.5).toInt() else 30
            for (fps in FPS_CANDIDATES) {
                if (fps > camFps) continue
                val range = aeRanges.filter { it.upper == fps }.maxByOrNull { it.lower } ?: continue
                val m = makeMode(size, fps, false, range) ?: continue
                out.putIfAbsent(m.key.removeSuffix("/hs"), m)
            }
        }

        // Constrained high-speed sessions (usually 1080p/720p at 120/240, some devices 4K)
        val hsSizes = try { map.highSpeedVideoSizes ?: emptyArray() } catch (e: Exception) { emptyArray() }
        for (size in hsSizes) {
            if (size.width < 1280) continue
            for (r in map.getHighSpeedVideoFpsRangesFor(size)) {
                if (r.lower != r.upper || r.upper < 60) continue
                if (out.containsKey("${size.width}x${size.height}@${r.upper}")) continue
                val m = makeMode(size, r.upper, true, r) ?: continue
                out.putIfAbsent(m.key, m)
            }
        }

        return out.values.sortedWith(compareByDescending<Mode> { it.score }.thenBy { it.highSpeed })
    }
}

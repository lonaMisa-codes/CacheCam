package com.example.cachecam

import android.hardware.camera2.CameraCharacteristics
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.util.Range
import android.util.Size
import kotlin.math.abs

/** One concrete way this device can record: resolution, frame rate, session type and encoder. */
data class Mode(
    val size: Size,
    val fps: Int,
    val highSpeed: Boolean,
    val mime: String,
    val codecName: String,
    val bitRate: Int,
    val aeRange: Range<Int>,
) {
    val key: String
        get() = "${size.width}x${size.height}@$fps" + if (highSpeed) "/hs" else ""

    val score: Long
        get() = size.width.toLong() * size.height * fps

    val resName: String
        get() = when {
            size.width >= 7680 -> "8K"
            size.width >= 3840 -> "4K"
            size.width >= 2560 -> "1440p"
            size.width >= 1920 -> "1080p"
            size.width >= 1280 -> "720p"
            else -> "${size.height}p"
        }

    val codecName2: String
        get() = if (mime == MediaFormat.MIMETYPE_VIDEO_HEVC) "HEVC" else "H.264"

    /** Compact text for the top bar, e.g. "4K 60fps". */
    val shortLabel: String
        get() = "$resName ${fps}fps"

    /** Full description for the picker. */
    val label: String
        get() = "$resName ${fps}fps (${size.width}x${size.height}, $codecName2, ${bitRate / 1_000_000} Mbps)" +
            if (highSpeed) " high-speed" else ""
}

/**
 * Works out every resolution/fps combination that BOTH the camera and a hardware video encoder
 * support on this device, best first (ranked by pixels per second, so 4K120 beats 4K60).
 */
object CameraModes {
    private val FPS_CANDIDATES = listOf(240, 120, 60, 30)
    private val MIMES = listOf(MediaFormat.MIMETYPE_VIDEO_HEVC, MediaFormat.MIMETYPE_VIDEO_AVC)

    private class Enc(val name: String, val mime: String, val vc: MediaCodecInfo.VideoCapabilities)

    private fun findEncoder(w: Int, h: Int, fps: Int): Enc? {
        val infos = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .filter { it.isEncoder }
            .sortedBy { if (it.isHardwareAccelerated) 0 else 1 }
        for (mime in MIMES) {
            for (info in infos) {
                if (info.supportedTypes.none { it.equals(mime, true) }) continue
                val vc = try {
                    info.getCapabilitiesForType(mime).videoCapabilities
                } catch (e: IllegalArgumentException) {
                    null
                } ?: continue
                try {
                    if (vc.areSizeAndRateSupported(w, h, fps.toDouble())) return Enc(info.name, mime, vc)
                } catch (e: IllegalArgumentException) {
                    // size not supported by this encoder
                }
            }
        }
        return null
    }

    private fun makeMode(size: Size, fps: Int, hs: Boolean, range: Range<Int>): Mode? {
        val enc = findEncoder(size.width, size.height, fps) ?: return null
        val bpp = if (enc.mime == MediaFormat.MIMETYPE_VIDEO_HEVC) 0.08 else 0.12
        val wanted = (size.width.toDouble() * size.height * fps * bpp).toLong()
        val br = enc.vc.bitrateRange
        val bitRate = wanted.coerceIn(br.lower.toLong(), br.upper.toLong()).toInt()
        return Mode(size, fps, hs, enc.mime, enc.name, bitRate, range)
    }

    fun enumerate(chars: CameraCharacteristics): List<Mode> {
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return emptyList()
        val aeRanges = chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            ?.toList() ?: emptyList()
        val out = LinkedHashMap<String, Mode>()

        // Normal (unconstrained) sessions
        for (size in map.getOutputSizes(MediaCodec::class.java) ?: emptyArray()) {
            if (size.width < 1280) continue
            val minDur = map.getOutputMinFrameDuration(MediaCodec::class.java, size)
            val camFps = if (minDur > 0) (1_000_000_000.0 / minDur + 0.5).toInt() else 30
            for (fps in FPS_CANDIDATES) {
                if (fps > camFps) continue
                val range = aeRanges.filter { it.upper == fps }.maxByOrNull { it.lower } ?: continue
                val m = makeMode(size, fps, false, range) ?: continue
                out.putIfAbsent(m.key, m)
            }
        }

        // Constrained high-speed sessions (usually 1080p/720p at 120/240, some devices 4K)
        val hsSizes = try { map.highSpeedVideoSizes ?: emptyArray() } catch (e: Exception) { emptyArray() }
        for (size in hsSizes) {
            if (size.width < 1280) continue
            for (r in map.getHighSpeedVideoFpsRangesFor(size)) {
                if (r.lower != r.upper || r.upper < 60) continue
                if (out.containsKey("${size.width}x${size.height}@${r.upper}")) continue
                val m = makeMode(size, r.upper, true, r) ?: continue
                out.putIfAbsent(m.key, m)
            }
        }

        return out.values.sortedWith(compareByDescending<Mode> { it.score }.thenBy { it.highSpeed })
    }

    /**
     * "Recommended" = the sharpest 16:9 picture this device can record at up to 60 fps and up to 4K.
     * Smooth, widely compatible, and doesn't overheat the phone like 120/240 fps can.
     * It differs from device to device because it is computed from what the hardware supports.
     */
    fun recommended(modes: List<Mode>): Mode? {
        val sane = modes.filter { it.fps <= 60 && it.size.width <= 3840 }
        val wide = sane.filter { abs(it.size.width.toDouble() / it.size.height - 16.0 / 9.0) < 0.02 }
        val pool = when {
            wide.isNotEmpty() -> wide
            sane.isNotEmpty() -> sane
            else -> modes
        }
        return pool.maxWithOrNull(
            compareBy<Mode> { it.size.width.toLong() * it.size.height }
                .thenBy { it.fps }
                .thenBy { !it.highSpeed }
        )
    }

    /**
     * Slow-motion pick: the highest frame rate the device offers (120 fps or more), preferring
     * up to 1080p so it stays smooth and doesn't overheat. Null if the device has no such mode.
     */
    fun slowMo(modes: List<Mode>): Mode? {
        val fast = modes.filter { it.fps >= 120 }
        if (fast.isEmpty()) return null
        val pool = fast.filter { it.size.width <= 1920 }.ifEmpty { fast }
        return pool.maxWithOrNull(
            compareBy<Mode> { it.fps }
                .thenBy { it.size.width.toLong() * it.size.height }
                .thenBy { !it.highSpeed }
        )
    }
}

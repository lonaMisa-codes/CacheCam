package com.example.cachecam

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {

    private lateinit var texture: TextureView
    private lateinit var status: TextView
    private lateinit var modeButton: TextView
    private lateinit var shutter: View

    private val camThread = HandlerThread("camera").apply { start() }
    private val camHandler = Handler(camThread.looper)

    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var recorder: CacheRecorder? = null
    private var chars: CameraCharacteristics? = null
    private var opening = false

    private var modes: List<Mode> = emptyList()
    private var mode: Mode? = null
    private val failedModes = HashSet<String>()
    private val prefs by lazy { getSharedPreferences("cachecam", MODE_PRIVATE) }

    private var pendingUri: Uri? = null
    private var pendingPfd: ParcelFileDescriptor? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        texture = TextureView(this)
        root.addView(texture, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(32, 24, 32, 24)
            setBackgroundColor(0x66000000)
            text = "Starting camera…"
        }
        root.addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))

        modeButton = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(32, 24, 32, 24)
            setBackgroundColor(0x66000000)
            text = "Mode"
            setOnClickListener { showModePicker() }
        }
        root.addView(modeButton, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))

        shutter = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.RED)
                setStroke(10, Color.WHITE)
            }
            setOnClickListener { toggleCapture() }
        }
        root.addView(shutter, FrameLayout.LayoutParams(180, 180, Gravity.END or Gravity.CENTER_VERTICAL).apply {
            marginEnd = 48
        })
        setContentView(root)

        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) = openCameraIfReady()
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
    }

    override fun onResume() {
        super.onResume()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
        } else if (texture.isAvailable) {
            openCameraIfReady()
        }
    }

    override fun onPause() {
        finishCapture()
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        camThread.quitSafely()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            openCameraIfReady()
        } else {
            status.text = "Camera permission is required"
        }
    }

    // ---- Camera -----------------------------------------------------------------------------

    @SuppressLint("MissingPermission")
    private fun openCameraIfReady() {
        if (camera != null || opening || !texture.isAvailable) return
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return

        val mgr = getSystemService(CAMERA_SERVICE) as CameraManager
        val id = mgr.cameraIdList.firstOrNull {
            mgr.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) ==
                CameraCharacteristics.LENS_FACING_BACK
        } ?: mgr.cameraIdList.first()
        val c = mgr.getCameraCharacteristics(id)
        chars = c

        modes = CameraModes.enumerate(c)
        val usable = modes.filter { it.key !in failedModes }
        val chosen = usable.firstOrNull { it.key == prefs.getString("mode", null) } ?: usable.firstOrNull()
        if (chosen == null) {
            status.text = "No supported recording mode found on this device"
            return
        }
        mode = chosen
        status.text = "Starting ${chosen.label}…"

        opening = true
        mgr.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(cam: CameraDevice) {
                opening = false
                camera = cam
                startSession(cam, chosen)
            }
            override fun onDisconnected(cam: CameraDevice) {
                opening = false
                cam.close(); camera = null
            }
            override fun onError(cam: CameraDevice, error: Int) {
                opening = false
                cam.close(); camera = null
                runOnUiThread { status.text = "Camera error ($error)" }
            }
        }, camHandler)
    }

    /** Preview stays <= 1080p (camera hardware only guarantees one big stream: the encoder). */
    private fun pickPreviewSize(m: Mode): Size {
        if (m.highSpeed) return m.size
        val map = chars!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val sizes = map.getOutputSizes(SurfaceTexture::class.java).toList()
        val ar = m.size.width.toDouble() / m.size.height
        return sizes.filter { it.width <= 1920 && abs(it.width.toDouble() / it.height - ar) < 0.02 }
            .maxByOrNull { it.width * it.height }
            ?: sizes.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height }
            ?: sizes.last()
    }

    @Suppress("DEPRECATION")
    private fun startSession(cam: CameraDevice, m: Mode) {
        val rec = try {
            CacheRecorder(m).also { it.start() }
        } catch (e: Exception) {
            modeFailed("encoder")
            return
        }
        recorder = rec

        val previewSize = pickPreviewSize(m)
        val st = texture.surfaceTexture ?: return
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        val preview = Surface(st)
        runOnUiThread { fitPreview(previewSize) }

        val callback = object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                session = s
                try {
                    val req = cam.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                        addTarget(preview)
                        addTarget(rec.inputSurface)
                        set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, m.aeRange)
                        set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                    }.build()
                    if (s is CameraConstrainedHighSpeedCaptureSession) {
                        s.setRepeatingBurst(s.createHighSpeedRequestList(req), null, camHandler)
                    } else {
                        s.setRepeatingRequest(req, null, camHandler)
                    }
                    runOnUiThread { status.text = "Buffering 3 s · ${m.label}" }
                } catch (e: Exception) {
                    modeFailed("request")
                }
            }
            override fun onConfigureFailed(s: CameraCaptureSession) = modeFailed("session")
        }

        val targets = listOf(preview, rec.inputSurface)
        try {
            if (m.highSpeed) cam.createConstrainedHighSpeedCaptureSession(targets, callback, camHandler)
            else cam.createCaptureSession(targets, callback, camHandler)
        } catch (e: Exception) {
            modeFailed("session")
        }
    }

    /** This device rejected the mode: remember that and fall back to the next best one. */
    private fun modeFailed(reason: String) {
        runOnUiThread {
            val bad = mode
            if (bad != null) failedModes.add(bad.key)
            closeCamera()
            status.text = "${bad?.label ?: "Mode"} not supported ($reason), trying next…"
            openCameraIfReady()
        }
    }

    /** Letterbox the preview to the camera's aspect ratio. */
    private fun fitPreview(size: Size) {
        val parent = texture.parent as View
        val pw = parent.width.takeIf { it > 0 } ?: return
        val ph = parent.height
        val aspect = size.width.toFloat() / size.height
        var w = pw
        var h = (pw / aspect).toInt()
        if (h > ph) { h = ph; w = (ph * aspect).toInt() }
        texture.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.CENTER)
    }

    private fun closeCamera() {
        opening = false
        try { session?.close() } catch (_: Exception) { }
        session = null
        try { camera?.close() } catch (_: Exception) { }
        camera = null
        recorder?.release()
        recorder = null
    }

    // ---- Mode picker ------------------------------------------------------------------------

    private fun showModePicker() {
        if (recorder?.isCapturing == true) {
            Toast.makeText(this, "Stop recording first", Toast.LENGTH_SHORT).show()
            return
        }
        val usable = modes.filter { it.key !in failedModes }
        if (usable.isEmpty()) return
        val labels = usable.mapIndexed { i, m -> if (i == 0) "${m.label}  (best)" else m.label }.toTypedArray()
        val checked = usable.indexOfFirst { it.key == mode?.key }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Recording mode")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                prefs.edit().putString("mode", usable[which].key).apply()
                dialog.dismiss()
                closeCamera()
                openCameraIfReady()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- Capture ----------------------------------------------------------------------------

    private fun toggleCapture() {
        val rec = recorder ?: return
        if (rec.isCapturing) {
            finishCapture()
            return
        }
        val name = "CacheCam_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CacheCam")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return
        val pfd = contentResolver.openFileDescriptor(uri, "rw") ?: return
        if (rec.startCapture(pfd.fileDescriptor)) {
            pendingUri = uri
            pendingPfd = pfd
            status.text = "● Recording (includes 3 s before the tap) · ${mode?.label}"
        } else {
            pfd.close()
            contentResolver.delete(uri, null, null)
            Toast.makeText(this, "Buffer not ready yet, try again in a second", Toast.LENGTH_SHORT).show()
        }
    }

    private fun finishCapture() {
        val uri = pendingUri ?: return
        recorder?.stopCapture()
        try { pendingPfd?.close() } catch (_: Exception) { }
        val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
        contentResolver.update(uri, done, null, null)
        pendingUri = null
        pendingPfd = null
        status.text = "Saved to Movies/CacheCam · buffering again · ${mode?.label}"
        Toast.makeText(this, "Saved to Movies/CacheCam", Toast.LENGTH_SHORT).show()
    }
}

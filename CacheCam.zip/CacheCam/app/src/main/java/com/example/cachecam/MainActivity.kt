package com.example.cachecam

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.util.Size
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {

    // ---- Views ------------------------------------------------------------------------------
    private lateinit var root: FrameLayout
    private lateinit var texture: TextureView
    private lateinit var recBorder: View
    private lateinit var flash: View
    private lateinit var modeChip: TextView
    private lateinit var preRollButton: TextView
    private lateinit var modeButton: TextView
    private lateinit var helpButton: TextView
    private lateinit var hud: TextView
    private lateinit var shutter: ShutterButton
    private lateinit var shutterHint: TextView
    private lateinit var shutterBox: LinearLayout

    // ---- Threads / camera state -------------------------------------------------------------
    private val ui = Handler(Looper.getMainLooper())
    private val camThread = HandlerThread("camera").apply { start() }
    private val camHandler = Handler(camThread.looper)

    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var recorder: CacheRecorder? = null
    private var chars: CameraCharacteristics? = null
    private var opening = false
    @Volatile private var sessionReady = false
    private var sensorOrientation = 90
    private var previewSize: Size? = null

    // ---- Modes ------------------------------------------------------------------------------
    private var usableModes: List<Mode> = emptyList()
    private var recommended: Mode? = null
    private var mode: Mode? = null
    private val failedModes = HashSet<String>()
    private val prefs by lazy { getSharedPreferences("cachecam", MODE_PRIVATE) }
    private var preRollSec = 3

    // ---- Capture state ----------------------------------------------------------------------
    private var pendingUri: Uri? = null
    private var pendingPfd: ParcelFileDescriptor? = null
    private var captureStartElapsed = 0L
    private var capturePreRollMs = 0L
    private var recPulse: ObjectAnimator? = null

    // ---- HUD --------------------------------------------------------------------------------
    private var hudMessage: String? = null
    private var lastHudKey = ""
    private val red = 0xFFE53935.toInt()
    private val green = 0xFF43A047.toInt()
    private val amber = 0xFFFFB300.toInt()
    private val grey = 0xFF9E9E9E.toInt()

    private val ticker = object : Runnable {
        override fun run() {
            updateHud()
            ui.postDelayed(this, 100)
        }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            runOnUiThread { applyLayoutForOrientation(); configureTransform() }
        }
    }

    // =========================================================================================
    // Lifecycle
    // =========================================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        preRollSec = prefs.getInt("preroll", 3)
        buildUi()
        applyLayoutForOrientation()
        refreshLabels()
        setContentView(root)

        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) = openCameraIfReady()
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) = configureTransform()
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        texture.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> configureTransform() }

        if (!prefs.getBoolean("seen_intro", false)) {
            prefs.edit().putBoolean("seen_intro", true).apply()
            ui.post { showHelp() }
        }
    }

    override fun onResume() {
        super.onResume()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, ui)
        ui.post(ticker)
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
        } else if (texture.isAvailable) {
            openCameraIfReady()
        }
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        finishCapture()
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        camThread.quitSafely()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayoutForOrientation()
        configureTransform()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val flags = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            window.decorView.systemUiVisibility = flags
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            openCameraIfReady()
        } else {
            hudMessage = "Camera permission is required"
        }
    }

    // =========================================================================================
    // UI construction
    // =========================================================================================

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun pill(color: Int) = GradientDrawable().apply {
        cornerRadius = dp(22).toFloat()
        setColor(color)
    }

    private fun chip(label: String, tip: String? = null, onClick: (() -> Unit)? = null): TextView {
        val tv = TextView(this)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 13f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(14), dp(9), dp(14), dp(9))
        tv.background = pill(0x99000000.toInt())
        tv.text = label
        if (tip != null) tv.tooltipText = tip
        if (onClick != null) tv.setOnClickListener { onClick() }
        return tv
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        texture = TextureView(this)
        root.addView(texture, FrameLayout.LayoutParams(-1, -1))

        recBorder = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(5), red)
            }
            visibility = View.GONE
        }
        root.addView(recBorder, FrameLayout.LayoutParams(-1, -1))

        flash = View(this).apply {
            setBackgroundColor(Color.WHITE)
            alpha = 0f
        }
        root.addView(flash, FrameLayout.LayoutParams(-1, -1))

        // ---- Top bar ----
        modeChip = chip(
            "…",
            "Current recording quality. ★ = Recommended for this device, ⚡ = Maximum."
        )
        preRollButton = chip(
            "⏪ 3 s",
            "Pre-roll: how many seconds from BEFORE your tap get saved. Tap to change."
        ) { cyclePreRoll() }
        modeButton = chip(
            "⚙ Quality",
            "Choose resolution and frame rate (Recommended is picked for your device)."
        ) { showModePicker() }
        helpButton = chip("?", "How Cache Cam works") { showHelp() }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topBar.addView(modeChip)
        topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        for (v in listOf(preRollButton, modeButton, helpButton)) {
            topBar.addView(v, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        }

        hud = chip(
            "Starting camera…",
            "Live status. Idle: how full the pre-roll buffer is. Recording: elapsed time."
        )

        val topContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), 0)
        }
        topContainer.addView(topBar, LinearLayout.LayoutParams(-1, -2))
        topContainer.addView(hud, LinearLayout.LayoutParams(-2, -2).apply {
            topMargin = dp(10)
            gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(topContainer, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // ---- Shutter ----
        shutter = ShutterButton(this).apply {
            tooltipText = "Tap once: saves the last few seconds and keeps recording. Tap again to stop."
            setOnClickListener { toggleCapture() }
        }
        shutterHint = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            background = pill(0x80000000.toInt())
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        shutterBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        shutterBox.addView(shutter, LinearLayout.LayoutParams(dp(88), dp(88)))
        shutterBox.addView(shutterHint, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        root.addView(shutterBox, FrameLayout.LayoutParams(-2, -2))
    }

    /** Shutter on the right edge in landscape, bottom centre in portrait. */
    private fun applyLayoutForOrientation() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        shutterBox.layoutParams = if (landscape) {
            FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(24) }
        } else {
            FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(40)
            }
        }
    }

    private fun refreshLabels() {
        val m = mode
        modeChip.text = if (m == null) "…" else {
            val star = when {
                m.key == recommended?.key -> "★ "
                m.key == usableModes.firstOrNull()?.key -> "⚡ "
                else -> ""
            }
            "$star${m.shortLabel} · ${m.codecName2}"
        }
        preRollButton.text = "⏪ $preRollSec s"
        shutterHint.text = if (recorder?.isCapturing == true) "Tap to stop"
        else "Tap to save the last $preRollSec s\n+ keep recording"
    }

    private fun showHelp() {
        val text = """
            How it works
            The camera is always buffering the last few seconds. Nothing is saved until you tap.

            • Tap the red button: saves the buffered footage AND keeps recording. You will see a red border and a REC timer.
            • Tap the red square: stops and saves the clip to Movies/CacheCam.

            Top bar
            • Left chip: current quality. ★ means Recommended for your device.
            • ⏪ Pre-roll: seconds saved from before your tap.
            • ⚙ Quality: pick another resolution / frame rate.

            Status pill
            Green = pre-roll ready. Amber = still filling. Red = recording.

            Tip: long-press any button to see what it does. Rotate the device freely, the orientation locks while recording.
        """.trimIndent()
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Welcome to Cache Cam")
            .setMessage(text)
            .setPositiveButton("Got it", null)
            .show()
    }

    // =========================================================================================
    // HUD
    // =========================================================================================

    private fun setHud(dot: Int, main: String, extra: String? = null) {
        val key = "$dot|$main|$extra"
        if (key == lastHudKey) return
        lastHudKey = key
        val sb = SpannableStringBuilder("● ")
        sb.setSpan(ForegroundColorSpan(dot), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val start = sb.length
        sb.append(main)
        sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (extra != null) sb.append("  ").append(extra)
        hud.text = sb
    }

    private fun fmtTime(totalSec: Long) = "%02d:%02d".format(totalSec / 60, totalSec % 60)

    private fun updateHud() {
        val rec = recorder
        when {
            rec != null && rec.isCapturing -> {
                val elapsedMs = SystemClock.elapsedRealtime() - captureStartElapsed + capturePreRollMs
                val blink = (SystemClock.elapsedRealtime() / 500) % 2L == 0L
                setHud(
                    if (blink) red else 0x66E53935,
                    "REC ${fmtTime(elapsedMs / 1000)}",
                    "incl. %.1f s before tap".format(capturePreRollMs / 1000.0)
                )
            }
            rec != null && sessionReady -> {
                val buffered = rec.bufferedUs() / 1_000_000.0
                if (buffered >= preRollSec - 0.25) {
                    setHud(green, "Ready", "%.1f s pre-roll buffered".format(minOf(buffered, preRollSec + 1.0)))
                } else {
                    setHud(amber, "Filling buffer", "%.1f / %d s".format(buffered, preRollSec))
                }
            }
            else -> setHud(grey, hudMessage ?: "Starting camera…")
        }
    }

    // =========================================================================================
    // Camera
    // =========================================================================================

    @SuppressLint("MissingPermission")
    private fun openCameraIfReady() {
        if (camera != null || opening || !texture.isAvailable) return
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return

        val mgr = getSystemService(CAMERA_SERVICE) as CameraManager
        val id = mgr.cameraIdList.firstOrNull {
            mgr.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) ==
                CameraCharacteristics.LENS_FACING_BACK
        } ?: mgr.cameraIdList.first()
        val c = mgr.getCameraCharacteristics(id)
        chars = c
        sensorOrientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

        usableModes = CameraModes.enumerate(c).filter { it.key !in failedModes }
        recommended = CameraModes.recommended(usableModes)
        val pref = prefs.getString("mode", "auto") ?: "auto"
        val chosen = if (pref == "auto") recommended
        else usableModes.firstOrNull { it.key == pref } ?: recommended
        if (chosen == null) {
            hudMessage = "No supported recording mode on this device"
            return
        }
        mode = chosen

        val allowed = allowedPreRolls(chosen)
        if (preRollSec !in allowed) preRollSec = allowed.filter { it <= preRollSec }.maxOrNull() ?: allowed.first()
        refreshLabels()
        hudMessage = "Starting ${chosen.shortLabel}…"

        opening = true
        mgr.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(cam: CameraDevice) {
                opening = false
                camera = cam
                startSession(cam, chosen)
            }
            override fun onDisconnected(cam: CameraDevice) {
                opening = false
                cam.close(); camera = null
            }
            override fun onError(cam: CameraDevice, error: Int) {
                opening = false
                cam.close(); camera = null
                hudMessage = "Camera error ($error)"
            }
        }, camHandler)
    }

    /** Preview stays <= 1080p: cameras only guarantee one big stream (the encoder). */
    private fun pickPreviewSize(m: Mode): Size {
        if (m.highSpeed) return m.size
        val map = chars!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val sizes = map.getOutputSizes(SurfaceTexture::class.java).toList()
        val ar = m.size.width.toDouble() / m.size.height
        return sizes.filter { it.width <= 1920 && abs(it.width.toDouble() / it.height - ar) < 0.02 }
            .maxByOrNull { it.width * it.height }
            ?: sizes.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height }
            ?: sizes.last()
    }

    @Suppress("DEPRECATION")
    private fun startSession(cam: CameraDevice, m: Mode) {
        val rec = try {
            CacheRecorder(m, preRollSec * 1_000_000L).also { it.start() }
        } catch (e: Exception) {
            modeFailed("encoder")
            return
        }
        recorder = rec

        val ps = pickPreviewSize(m)
        previewSize = ps
        val st = texture.surfaceTexture ?: return
        st.setDefaultBufferSize(ps.width, ps.height)
        val preview = Surface(st)
        runOnUiThread { configureTransform() }

        val callback = object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                session = s
                try {
                    val req = cam.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                        addTarget(preview)
                        addTarget(rec.inputSurface)
                        set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, m.aeRange)
                        set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                    }.build()
                    if (s is CameraConstrainedHighSpeedCaptureSession) {
                        s.setRepeatingBurst(s.createHighSpeedRequestList(req), null, camHandler)
                    } else {
                        s.setRepeatingRequest(req, null, camHandler)
                    }
                    hudMessage = null
                    sessionReady = true
                } catch (e: Exception) {
                    modeFailed("request")
                }
            }
            override fun onConfigureFailed(s: CameraCaptureSession) = modeFailed("session")
        }

        val targets = listOf(preview, rec.inputSurface)
        try {
            if (m.highSpeed) cam.createConstrainedHighSpeedCaptureSession(targets, callback, camHandler)
            else cam.createCaptureSession(targets, callback, camHandler)
        } catch (e: Exception) {
            modeFailed("session")
        }
    }

    /** This device rejected the mode: remember that and fall back to the next best one. */
    private fun modeFailed(reason: String) {
        runOnUiThread {
            val bad = mode
            if (bad != null) failedModes.add(bad.key)
            closeCamera()
            hudMessage = "${bad?.shortLabel ?: "Mode"} not supported ($reason), trying next…"
            openCameraIfReady()
        }
    }

    private fun closeCamera() {
        opening = false
        sessionReady = false
        try { session?.close() } catch (_: Exception) { }
        session = null
        try { camera?.close() } catch (_: Exception) { }
        camera = null
        recorder?.release()
        recorder = null
    }

    // ---- Orientation ------------------------------------------------------------------------

    @Suppress("DEPRECATION")
    private fun rotationDegrees(): Int = when (windowManager.defaultDisplay.rotation) {
        Surface.ROTATION_90 -> 90
        Surface.ROTATION_180 -> 180
        Surface.ROTATION_270 -> 270
        else -> 0
    }

    /** Clockwise rotation needed to make the (sensor-oriented) image upright on screen / in the file. */
    private fun uprightRotation(): Int = (sensorOrientation - rotationDegrees() + 360) % 360

    /**
     * The camera delivers frames in sensor orientation. Undo TextureView's default stretch,
     * rotate the frame upright for the current screen rotation, then fit it inside the view.
     */
    private fun configureTransform() {
        val ps = previewSize ?: return
        val vw = texture.width.toFloat()
        val vh = texture.height.toFloat()
        if (vw == 0f || vh == 0f) return
        val rot = uprightRotation()
        val cx = vw / 2f
        val cy = vh / 2f
        val m = Matrix()
        m.postScale(ps.width / vw, ps.height / vh, cx, cy)
        m.postRotate(rot.toFloat(), cx, cy)
        val sideways = rot % 180 != 0
        val cw = if (sideways) ps.height.toFloat() else ps.width.toFloat()
        val ch = if (sideways) ps.width.toFloat() else ps.height.toFloat()
        val s = minOf(vw / cw, vh / ch)
        m.postScale(s, s, cx, cy)
        texture.setTransform(m)
    }

    // =========================================================================================
    // Quality picker + pre-roll
    // =========================================================================================

    private fun allowedPreRolls(m: Mode): List<Int> =
        listOf(3, 5, 10).filter { m.bitRate / 8.0 * (it + 1) <= 150_000_000 }.ifEmpty { listOf(3) }

    private fun cyclePreRoll() {
        val m = mode ?: return
        if (recorder?.isCapturing == true) {
            Toast.makeText(this, "Stop recording first", Toast.LENGTH_SHORT).show()
            return
        }
        val opts = allowedPreRolls(m)
        preRollSec = opts.firstOrNull { it > preRollSec } ?: opts.first()
        prefs.edit().putInt("preroll", preRollSec).apply()
        recorder?.preRollUs = preRollSec * 1_000_000L
        refreshLabels()
        Toast.makeText(this, "Pre-roll: $preRollSec s (buffer refills in a moment)", Toast.LENGTH_SHORT).show()
    }

    private fun showModePicker() {
        if (recorder?.isCapturing == true) {
            Toast.makeText(this, "Stop recording first", Toast.LENGTH_SHORT).show()
            return
        }
        if (usableModes.isEmpty()) return
        val rec = recommended
        val maxMode = usableModes.first()
        val ordered = listOfNotNull(rec) + usableModes.filter { it.key != rec?.key }
        val labels = ordered.map {
            val tag = when {
                it.key == rec?.key -> "★ Recommended\n"
                it.key == maxMode.key -> "⚡ Maximum\n"
                else -> ""
            }
            tag + it.label
        }.toTypedArray()
        val checked = ordered.indexOfFirst { it.key == mode?.key }.coerceAtLeast(0)
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Recording quality")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                val picked = ordered[which]
                prefs.edit().putString("mode", if (picked.key == rec?.key) "auto" else picked.key).apply()
                dialog.dismiss()
                closeCamera()
                openCameraIfReady()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =========================================================================================
    // Capture
    // =========================================================================================

    private fun flashScreen() {
        flash.animate().cancel()
        flash.alpha = 0.55f
        flash.animate().alpha(0f).setDuration(220).setInterpolator(AccelerateInterpolator()).start()
    }

    private fun toggleCapture() {
        val rec = recorder
        if (rec == null || !sessionReady) {
            Toast.makeText(this, "Camera is still starting…", Toast.LENGTH_SHORT).show()
            return
        }
        if (rec.isCapturing) {
            finishCapture()
            return
        }
        val name = "CacheCam_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CacheCam")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return
        val pfd = contentResolver.openFileDescriptor(uri, "rw") ?: return
        val preUs = rec.startCapture(pfd.fileDescriptor, uprightRotation())
        if (preUs >= 0) {
            pendingUri = uri
            pendingPfd = pfd
            captureStartElapsed = SystemClock.elapsedRealtime()
            capturePreRollMs = preUs / 1000
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED
            shutter.recording = true
            recBorder.visibility = View.VISIBLE
            recPulse = ObjectAnimator.ofFloat(recBorder, "alpha", 1f, 0.3f).apply {
                duration = 700
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                start()
            }
            refreshLabels()
            shutter.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            flashScreen()
        } else {
            pfd.close()
            contentResolver.delete(uri, null, null)
            Toast.makeText(this, "Buffer not ready yet, try again in a second", Toast.LENGTH_SHORT).show()
        }
    }

    private fun finishCapture() {
        val uri = pendingUri ?: return
        val totalSec = (SystemClock.elapsedRealtime() - captureStartElapsed + capturePreRollMs) / 1000
        recorder?.stopCapture()
        try { pendingPfd?.close() } catch (_: Exception) { }
        val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
        contentResolver.update(uri, done, null, null)
        pendingUri = null
        pendingPfd = null

        recPulse?.cancel()
        recPulse = null
        recBorder.alpha = 1f
        recBorder.visibility = View.GONE
        shutter.recording = false
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        refreshLabels()
        shutter.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        Toast.makeText(this, "Saved ${fmtTime(totalSec)} clip to Movies/CacheCam", Toast.LENGTH_LONG).show()
    }
}

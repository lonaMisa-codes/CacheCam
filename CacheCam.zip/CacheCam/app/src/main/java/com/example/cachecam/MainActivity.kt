package com.example.cachecam

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.HapticFeedbackConstants
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {

    // ---- Views ------------------------------------------------------------------------------
    private lateinit var root: FrameLayout
    private lateinit var texture: TextureView
    private lateinit var recBorder: View
    private lateinit var flash: View
    private lateinit var modeChip: TextView
    private lateinit var preRollButton: TextView
    private lateinit var modeButton: TextView
    private lateinit var helpButton: TextView
    private lateinit var hud: TextView
    private lateinit var shutter: ShutterButton
    private lateinit var shutterHint: TextView
    private lateinit var shutterBox: LinearLayout

    // ---- Threads / camera state -------------------------------------------------------------
    private val ui = Handler(Looper.getMainLooper())
    private val camThread = HandlerThread("camera").apply { start() }
    private val camHandler = Handler(camThread.looper)

    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var recorder: CacheRecorder? = null
    private var chars: CameraCharacteristics? = null
    private var opening = false
    @Volatile private var sessionReady = false
    private var sensorOrientation = 90
    private var previewSize: Size? = null

    // ---- Modes ------------------------------------------------------------------------------
    private var usableModes: List<Mode> = emptyList()
    private var recommended: Mode? = null
    private var mode: Mode? = null
    private val failedModes = HashSet<String>()
    private val prefs by lazy { getSharedPreferences("cachecam", MODE_PRIVATE) }
    private var preRollSec = 3

    // ---- Camera mode (Cache / Video / Slo-mo) and preview-rotation override -------------------
    private var captureMode = "cache"
    private var previewFix = 0   // 0 = automatic, else extra rotation in degrees
    private lateinit var modeViews: Map<String, TextView>
    private lateinit var fixButton: TextView
    private lateinit var galleryButton: TextView
    private lateinit var flipButton: TextView
    private lateinit var zoomChip: TextView
    private lateinit var focusRing: View

    // ---- Front camera, zoom, focus, audio ----
    private var useFront = false
    private var zoom = 1f
    private var zoomMin = 1f
    private var zoomMax = 1f
    private var useZoomRatio = false
    private var zoomKeysSet = false
    private var activeArray: Rect? = null
    private var requestBuilder: CaptureRequest.Builder? = null
    private var realtimeClock = false
    private var audioOn = false
    private var lastPinchAt = 0L
    private val previewMatrix = Matrix()

    // ---- Capture state ----------------------------------------------------------------------
    private var pendingUri: Uri? = null
    private var pendingPfd: ParcelFileDescriptor? = null
    private var captureStartElapsed = 0L
    private var capturePreRollMs = 0L
    private var recPulse: ObjectAnimator? = null

    // ---- HUD --------------------------------------------------------------------------------
    private var hudMessage: String? = null
    private var lastHudKey = ""
    private val red = 0xFFE53935.toInt()
    private val green = 0xFF43A047.toInt()
    private val amber = 0xFFFFB300.toInt()
    private val grey = 0xFF9E9E9E.toInt()

    private val ticker = object : Runnable {
        override fun run() {
            updateHud()
            ui.postDelayed(this, 100)
        }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            runOnUiThread { applyLayoutForOrientation(); configureTransform() }
        }
    }

    // =========================================================================================
    // Lifecycle
    // =========================================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        preRollSec = prefs.getInt("preroll", 3)
        captureMode = prefs.getString("capmode", "cache") ?: "cache"
        previewFix = prefs.getInt("previewfix", 0)
        useFront = prefs.getBoolean("front", false)
        buildUi()
        applyLayoutForOrientation()
        refreshLabels()
        setContentView(root)

        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) = openCameraIfReady()
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) = configureTransform()
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        texture.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> configureTransform() }

        if (!prefs.getBoolean("seen_intro", false)) {
            prefs.edit().putBoolean("seen_intro", true).apply()
            ui.post { showHelp() }
        }
    }

    override fun onResume() {
        super.onResume()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, ui)
        ui.post(ticker)
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(permissionsToAsk(), 1)
        } else if (needsAudioAsk()) {
            requestPermissions(permissionsToAsk(), 1)
        } else if (texture.isAvailable) {
            openCameraIfReady()
        }
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        finishCapture()
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        camThread.quitSafely()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayoutForOrientation()
        configureTransform()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val flags = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            window.decorView.systemUiVisibility = flags
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            // Mic permission arrived after the camera was already running: restart so audio is included
            if (camera != null && audioPermitted() && !audioOn && captureMode != "slomo") closeCamera()
            openCameraIfReady()
        } else {
            hudMessage = "Camera permission is required"
        }
    }

    // =========================================================================================
    // UI construction
    // =========================================================================================

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun pill(color: Int) = GradientDrawable().apply {
        cornerRadius = dp(22).toFloat()
        setColor(color)
    }

    private fun chip(label: String, tip: String? = null, onClick: (() -> Unit)? = null): TextView {
        val tv = TextView(this)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 13f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(14), dp(9), dp(14), dp(9))
        tv.background = pill(0x99000000.toInt())
        tv.text = label
        if (tip != null) tv.tooltipText = tip
        if (onClick != null) tv.setOnClickListener { onClick() }
        return tv
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        texture = TextureView(this)
        root.addView(texture, FrameLayout.LayoutParams(-1, -1))

        recBorder = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(5), red)
            }
            visibility = View.GONE
        }
        root.addView(recBorder, FrameLayout.LayoutParams(-1, -1))

        flash = View(this).apply {
            setBackgroundColor(Color.WHITE)
            alpha = 0f
        }
        root.addView(flash, FrameLayout.LayoutParams(-1, -1))

        // ---- Top bar ----
        modeChip = chip(
            "…",
            "Current recording quality. ★ = Recommended for this device, ⚡ = Maximum."
        )
        preRollButton = chip(
            "⏪ 3 s",
            "Pre-roll: how many seconds from BEFORE your tap get saved. Tap to change."
        ) { cyclePreRoll() }
        modeButton = chip(
            "⚙",
            "Choose resolution and frame rate (Recommended is picked for your device)."
        ) { showModePicker() }
        helpButton = chip("?", "How Cache Cam works") { showHelp() }
        galleryButton = chip("🎞", "Gallery: watch, share or delete your clips") {
            startActivity(Intent(this, GalleryActivity::class.java))
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topBar.addView(modeChip)
        topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        for (v in listOf(preRollButton, modeButton, galleryButton, helpButton)) {
            topBar.addView(v, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        }

        hud = chip(
            "Starting camera…",
            "Live status. Idle: how full the pre-roll buffer is. Recording: elapsed time."
        )

        val topContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), 0)
        }
        topContainer.addView(topBar, LinearLayout.LayoutParams(-1, -2))
        topContainer.addView(hud, LinearLayout.LayoutParams(-2, -2).apply {
            topMargin = dp(10)
            gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(topContainer, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // ---- Shutter ----
        shutter = ShutterButton(this).apply {
            tooltipText = "Tap once: saves the last few seconds and keeps recording. Tap again to stop."
            setOnClickListener { toggleCapture() }
        }
        shutterHint = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            background = pill(0x80000000.toInt())
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        shutterBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        modeViews = linkedMapOf(
            "cache" to modeTab("cache", "CACHE",
                "Cache: saves the seconds BEFORE you tap, then keeps recording"),
            "video" to modeTab("video", "VIDEO",
                "Video: normal recording, starts when you tap"),
            "slomo" to modeTab("slomo", "SLO-MO",
                "Slow motion: fastest frame rate your device allows, plays back slowed down"),
        )
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        for (v in modeViews.values) {
            modeRow.addView(v, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(4); marginEnd = dp(4) })
        }
        shutterBox.addView(modeRow, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(12) })
        shutterBox.addView(shutter, LinearLayout.LayoutParams(dp(88), dp(88)))
        shutterBox.addView(shutterHint, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        root.addView(shutterBox, FrameLayout.LayoutParams(-2, -2))

        fixButton = chip(
            "↻ Auto",
            "Preview looks sideways or upside-down? Tap to rotate it until it looks right. " +
                "This only changes the on-screen preview, never your saved video."
        ) { cyclePreviewFix() }
        root.addView(fixButton, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply {
            marginStart = dp(16)
            bottomMargin = dp(24)
        })

        // Left edge, centred: camera flip + zoom level
        flipButton = chip("🔄", "Switch between the back and front camera") { flipCamera() }
        zoomChip = chip("1.0×", "Pinch anywhere on the preview to zoom. Tap here to reset to 1×.") { setZoom(1f) }
        val leftCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        leftCol.addView(flipButton, LinearLayout.LayoutParams(-2, -2))
        leftCol.addView(zoomChip, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) })
        root.addView(leftCol, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL).apply {
            marginStart = dp(16)
        })

        // Tap-to-focus ring
        focusRing = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), Color.WHITE)
            }
            visibility = View.GONE
        }
        root.addView(focusRing, FrameLayout.LayoutParams(dp(72), dp(72)))

        // Pinch = zoom, single tap = focus. Buttons keep their own touches.
        root.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            if (!scaleDetector.isInProgress) tapDetector.onTouchEvent(ev)
            true
        }
    }

    /** Shutter on the right edge in landscape, bottom centre in portrait. */
    private fun applyLayoutForOrientation() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        shutterBox.layoutParams = if (landscape) {
            FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(24) }
        } else {
            FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(40)
            }
        }
    }

    private fun refreshLabels() {
        val m = mode
        modeChip.text = if (m == null) "…" else {
            val star = when {
                captureMode == "slomo" -> "🐢 "
                m.key == recommended?.key -> "★ "
                m.key == usableModes.firstOrNull()?.key -> "⚡ "
                else -> ""
            }
            "$star${m.shortLabel} · ${m.codecName2}" +
                (if (captureMode == "slomo") " · ${(m.fps / 30).coerceIn(1, 8)}× slower" else "") +
                if (audioOn) " · 🎤" else " · 🔇"
        }
        preRollButton.text = "⏪ $preRollSec s"
        shutterHint.text = when {
            recorder?.isCapturing == true -> "Tap to stop"
            captureMode == "video" -> "Tap to start recording"
            captureMode == "slomo" -> "Slow motion · saves the last $preRollSec s\n+ keeps recording"
            else -> "Tap to save the last $preRollSec s\n+ keep recording"
        }
        preRollButton.visibility = if (captureMode == "video") View.GONE else View.VISIBLE
        applyModeStyles()
    }

    private fun showHelp() {
        val text = """
            How it works
            The camera is always buffering the last few seconds. Nothing is saved until you tap.

            • Tap the red button: saves the buffered footage AND keeps recording. You will see a red border and a REC timer.
            • Tap the red square: stops and saves the clip to Movies/CacheCam.

            Top bar
            • Left chip: current quality. ★ means Recommended for your device.
            • ⏪ Pre-roll: seconds saved from before your tap.
            • ⚙ Quality: pick another resolution / frame rate.
            • 🎞 Gallery: watch, share or delete your clips.
            • 🔄 (left edge): switch front / back camera. Pinch to zoom, tap to focus.
            • 🎤 after the quality = recording sound, 🔇 = silent (no mic permission, or slo-mo).

            Status pill
            Green = pre-roll ready. Amber = still filling. Red = recording.

            Modes (above the red button)
            • CACHE: saves the seconds before your tap, then keeps recording.
            • VIDEO: normal video, starts when you tap.
            • SLO-MO: fastest frame rate your device allows, plays back slowed down.

            Preview looks sideways? Tap ↻ (bottom left) until it looks right. It only changes the preview, not the saved video.

            Tip: long-press any button to see what it does.
        """.trimIndent()
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Welcome to Cache Cam")
            .setMessage(text)
            .setPositiveButton("Got it", null)
            .show()
    }

    // =========================================================================================
    // HUD
    // =========================================================================================

    private fun setHud(dot: Int, main: String, extra: String? = null) {
        val key = "$dot|$main|$extra"
        if (key == lastHudKey) return
        lastHudKey = key
        val sb = SpannableStringBuilder("● ")
        sb.setSpan(ForegroundColorSpan(dot), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val start = sb.length
        sb.append(main)
        sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (extra != null) sb.append("  ").append(extra)
        hud.text = sb
    }

    private fun fmtTime(totalSec: Long) = "%02d:%02d".format(totalSec / 60, totalSec % 60)

    private fun updateHud() {
        val rec = recorder
        when {
            rec != null && rec.isCapturing -> {
                val elapsedMs = SystemClock.elapsedRealtime() - captureStartElapsed + capturePreRollMs
                val blink = (SystemClock.elapsedRealtime() / 500) % 2L == 0L
                setHud(
                    if (blink) red else 0x66E53935,
                    "REC ${fmtTime(elapsedMs / 1000)}",
                    if (capturePreRollMs > 0) "incl. %.1f s before tap".format(capturePreRollMs / 1000.0) else null
                )
            }
            rec != null && sessionReady && captureMode == "video" ->
                setHud(green, "Ready", "records from the moment you tap")
            rec != null && sessionReady -> {
                val buffered = rec.bufferedUs() / 1_000_000.0
                if (buffered >= preRollSec - 0.25) {
                    setHud(green, "Ready", "%.1f s pre-roll buffered".format(minOf(buffered, preRollSec + 1.0)))
                } else {
                    setHud(amber, "Filling buffer", "%.1f / %d s".format(buffered, preRollSec))
                }
            }
            else -> setHud(grey, hudMessage ?: "Starting camera…")
        }
    }

    // =========================================================================================
    // Camera
    // =========================================================================================

    @SuppressLint("MissingPermission")
    private fun openCameraIfReady() {
        if (camera != null || opening || !texture.isAvailable) return
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return

        val mgr = getSystemService(CAMERA_SERVICE) as CameraManager
        val wanted = if (useFront) CameraCharacteristics.LENS_FACING_FRONT
        else CameraCharacteristics.LENS_FACING_BACK
        val id = mgr.cameraIdList.firstOrNull {
            mgr.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == wanted
        } ?: run {
            if (useFront) {
                useFront = false
                prefs.edit().putBoolean("front", false).apply()
                Toast.makeText(this, "No front camera found, using the back camera", Toast.LENGTH_LONG).show()
            }
            mgr.cameraIdList.first()
        }
        val c = mgr.getCameraCharacteristics(id)
        chars = c
        sensorOrientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        realtimeClock = c.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE) ==
            CameraMetadata.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME
        setupZoom(c)

        usableModes = CameraModes.enumerate(c).filter { it.key !in failedModes }
        recommended = CameraModes.recommended(usableModes)
        val pref = prefs.getString("mode", "auto") ?: "auto"
        val slow = if (captureMode == "slomo") CameraModes.slowMo(usableModes) else null
        if (captureMode == "slomo" && slow == null) {
            captureMode = "cache"
            prefs.edit().putString("capmode", "cache").apply()
            Toast.makeText(this, "Slow motion isn't supported on this device", Toast.LENGTH_LONG).show()
        }
        val chosen = slow ?: (if (pref == "auto") recommended
        else usableModes.firstOrNull { it.key == pref } ?: recommended)
        if (chosen == null) {
            hudMessage = "No supported recording mode on this device"
            return
        }
        mode = chosen
        audioOn = audioPermitted() && captureMode != "slomo"

        val allowed = allowedPreRolls(chosen)
        if (preRollSec !in allowed) preRollSec = allowed.filter { it <= preRollSec }.maxOrNull() ?: allowed.first()
        refreshLabels()
        hudMessage = "Starting ${chosen.shortLabel}…"

        opening = true
        mgr.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(cam: CameraDevice) {
                opening = false
                camera = cam
                startSession(cam, chosen)
            }
            override fun onDisconnected(cam: CameraDevice) {
                opening = false
                cam.close(); camera = null
            }
            override fun onError(cam: CameraDevice, error: Int) {
                opening = false
                cam.close(); camera = null
                hudMessage = "Camera error ($error)"
            }
        }, camHandler)
    }

    /** Preview stays <= 1080p: cameras only guarantee one big stream (the encoder). */
    private fun pickPreviewSize(m: Mode): Size {
        if (m.highSpeed) return m.size
        val map = chars!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val sizes = map.getOutputSizes(SurfaceTexture::class.java).toList()
        val ar = m.size.width.toDouble() / m.size.height
        return sizes.filter { it.width <= 1920 && abs(it.width.toDouble() / it.height - ar) < 0.02 }
            .maxByOrNull { it.width * it.height }
            ?: sizes.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height }
            ?: sizes.last()
    }

    @Suppress("DEPRECATION")
    private fun startSession(cam: CameraDevice, m: Mode) {
        val rec = try {
            CacheRecorder(
                m,
                if (captureMode == "video") 0L else preRollSec * 1_000_000L,
                if (captureMode == "slomo") (m.fps / 30).coerceIn(1, 8) else 1,
                audioOn,
                realtimeClock,
            ).also {
                it.start()
                audioOn = it.hasAudio
            }
        } catch (e: Exception) {
            modeFailed("encoder")
            return
        }
        recorder = rec
        runOnUiThread { refreshLabels() }

        val ps = pickPreviewSize(m)
        previewSize = ps
        val st = texture.surfaceTexture ?: return
        st.setDefaultBufferSize(ps.width, ps.height)
        val preview = Surface(st)
        runOnUiThread { configureTransform() }

        val callback = object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                session = s
                try {
                    val afCont = chars?.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
                        ?.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO) == true
                    requestBuilder = cam.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                        addTarget(preview)
                        addTarget(rec.inputSurface)
                        set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, m.aeRange)
                        if (afCont) set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                    }
                    zoomKeysSet = false
                    if (applyRepeating()) {
                        hudMessage = null
                        sessionReady = true
                    } else {
                        modeFailed("request")
                    }
                } catch (e: Exception) {
                    modeFailed("request")
                }
            }
            override fun onConfigureFailed(s: CameraCaptureSession) = modeFailed("session")
        }

        val targets = listOf(preview, rec.inputSurface)
        try {
            if (m.highSpeed) cam.createConstrainedHighSpeedCaptureSession(targets, callback, camHandler)
            else cam.createCaptureSession(targets, callback, camHandler)
        } catch (e: Exception) {
            modeFailed("session")
        }
    }

    /** This device rejected the mode: remember that and fall back to the next best one. */
    private fun modeFailed(reason: String) {
        runOnUiThread {
            val bad = mode
            if (bad != null) failedModes.add(bad.key)
            closeCamera()
            hudMessage = "${bad?.shortLabel ?: "Mode"} not supported ($reason), trying next…"
            openCameraIfReady()
        }
    }

    private fun closeCamera() {
        opening = false
        sessionReady = false
        requestBuilder = null
        try { session?.close() } catch (_: Exception) { }
        session = null
        try { camera?.close() } catch (_: Exception) { }
        camera = null
        recorder?.release()
        recorder = null
    }

    // ---- Orientation ------------------------------------------------------------------------

    @Suppress("DEPRECATION")
    private fun rotationDegrees(): Int = when (windowManager.defaultDisplay.rotation) {
        Surface.ROTATION_90 -> 90
        Surface.ROTATION_180 -> 180
        Surface.ROTATION_270 -> 270
        else -> 0
    }

    /** Clockwise rotation needed to make the (sensor-oriented) image upright on screen / in the file. */
    private fun uprightRotation(): Int =
        if (useFront) (sensorOrientation + rotationDegrees()) % 360
        else (sensorOrientation - rotationDegrees() + 360) % 360

    /**
     * The camera system already rotates the picture upright for the device's NATURAL orientation
     * (phones: portrait, many tablets: landscape) and TextureView stretches it to the view.
     * So: undo the stretch using the natural-orientation aspect, counter-rotate by the current
     * screen rotation, then fit inside the view with black bars. Works for any screen shape.
     * [previewFix] adds a manual rotation in case a device reports its sensor wrongly.
     */
    private fun configureTransform() {
        val ps = previewSize ?: return
        val vw = texture.width.toFloat()
        val vh = texture.height.toFloat()
        if (vw == 0f || vh == 0f) return

        // Size of the picture as delivered (upright in natural orientation)
        val sensor = (sensorOrientation + previewFix) % 360
        val portraitContent = sensor % 180 != 0
        val cw = if (portraitContent) ps.height.toFloat() else ps.width.toFloat()
        val ch = if (portraitContent) ps.width.toFloat() else ps.height.toFloat()

        val rot = -rotationDegrees() + previewFix
        val cx = vw / 2f
        val cy = vh / 2f
        val m = Matrix()
        m.postScale(cw / vw, ch / vh, cx, cy)        // undo TextureView's stretch
        m.postRotate(rot.toFloat(), cx, cy)           // counter-rotate for the screen rotation
        val sideways = ((rot % 180) + 180) % 180 != 0
        val rw = if (sideways) ch else cw
        val rh = if (sideways) cw else ch
        val s = minOf(vw / rw, vh / rh)
        m.postScale(s, s, cx, cy)                     // fit inside the view
        if (useFront) m.postScale(-1f, 1f, cx, cy)    // selfie preview is mirrored; the saved video is not
        previewMatrix.set(m)
        texture.setTransform(m)
    }

    // =========================================================================================
    // Quality picker + pre-roll
    // =========================================================================================

    // ---- Permissions ----

    private fun audioPermitted() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun needsAudioAsk() = !audioPermitted() && !prefs.getBoolean("audio_asked", false)

    private fun permissionsToAsk(): Array<String> {
        val list = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            list.add(Manifest.permission.CAMERA)
        }
        if (needsAudioAsk()) {
            list.add(Manifest.permission.RECORD_AUDIO)
            prefs.edit().putBoolean("audio_asked", true).apply()
        }
        return list.toTypedArray()
    }

    // ---- Zoom ----

    private val scaleDetector by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                lastPinchAt = SystemClock.uptimeMillis()
                setZoom(zoom * detector.scaleFactor)
                return true
            }
        })
    }

    private val tapDetector by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (SystemClock.uptimeMillis() - lastPinchAt > 400) tapToFocus(e.x, e.y)
                return true
            }
        })
    }

    private fun setupZoom(c: CameraCharacteristics) {
        activeArray = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
        zoom = 1f
        zoomKeysSet = false
        val ratio = if (Build.VERSION.SDK_INT >= 30) c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) else null
        if (ratio != null) {
            useZoomRatio = true
            zoomMax = minOf(ratio.upper, 10f)
        } else {
            useZoomRatio = false
            zoomMax = minOf(c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f, 10f)
        }
        zoomMin = 1f
        zoomChip.visibility = if (zoomMax > 1.05f) View.VISIBLE else View.GONE
        updateZoomChip()
    }

    private fun updateZoomChip() {
        zoomChip.text = "%.1f×".format(zoom)
    }

    private fun setZoom(z: Float) {
        zoom = z.coerceIn(zoomMin, zoomMax)
        applyRepeating()
        updateZoomChip()
    }

    /** The part of the sensor currently visible (the full array when not zoomed). */
    private fun currentCrop(): Rect? {
        val a = activeArray ?: return null
        val w = (a.width() / zoom).toInt()
        val h = (a.height() / zoom).toInt()
        return Rect(a.centerX() - w / 2, a.centerY() - h / 2, a.centerX() + w / 2, a.centerY() + h / 2)
    }

    private fun applyZoom(b: CaptureRequest.Builder) {
        if (zoom <= 1.001f && !zoomKeysSet) return
        if (useZoomRatio && Build.VERSION.SDK_INT >= 30) {
            b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom)
        } else {
            currentCrop()?.let { b.set(CaptureRequest.SCALER_CROP_REGION, it) }
        }
        zoomKeysSet = zoom > 1.001f
    }

    /** (Re)sends the repeating request with the current zoom / focus settings. */
    private fun applyRepeating(): Boolean {
        val s = session ?: return false
        val b = requestBuilder ?: return false
        return try {
            applyZoom(b)
            val req = b.build()
            if (s is CameraConstrainedHighSpeedCaptureSession) {
                s.setRepeatingBurst(s.createHighSpeedRequestList(req), null, camHandler)
            } else {
                s.setRepeatingRequest(req, null, camHandler)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---- Tap to focus ----

    private fun tapToFocus(x: Float, y: Float) {
        val c = chars ?: return
        val a = activeArray ?: return
        val b = requestBuilder ?: return
        val inv = Matrix()
        if (!previewMatrix.invert(inv)) return
        val pts = floatArrayOf(x, y)
        inv.mapPoints(pts)
        val nx = pts[0] / texture.width
        val ny = pts[1] / texture.height
        if (nx < 0f || nx > 1f || ny < 0f || ny > 1f) return   // tapped the black bars

        // Picture is the sensor image rotated clockwise by the sensor orientation: undo that
        val s = (sensorOrientation + previewFix) % 360
        val sx: Float
        val sy: Float
        when (s) {
            90 -> { sx = ny; sy = 1f - nx }
            180 -> { sx = 1f - nx; sy = 1f - ny }
            270 -> { sx = 1f - ny; sy = nx }
            else -> { sx = nx; sy = ny }
        }
        val crop = currentCrop() ?: a
        val px = crop.left + sx * crop.width()
        val py = crop.top + sy * crop.height()
        val side = (0.12f * maxOf(crop.width(), crop.height())).toInt()
        val rect = Rect((px - side / 2).toInt(), (py - side / 2).toInt(), (px + side / 2).toInt(), (py + side / 2).toInt())
        if (!rect.intersect(a)) return
        val regions = arrayOf(MeteringRectangle(rect, MeteringRectangle.METERING_WEIGHT_MAX))
        if ((c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0) > 0) b.set(CaptureRequest.CONTROL_AF_REGIONS, regions)
        if ((c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0) > 0) b.set(CaptureRequest.CONTROL_AE_REGIONS, regions)
        applyRepeating()
        showFocusRing(x, y)
    }

    private fun showFocusRing(x: Float, y: Float) {
        val size = dp(72)
        focusRing.animate().cancel()
        focusRing.x = x - size / 2f
        focusRing.y = y - size / 2f
        focusRing.alpha = 1f
        focusRing.scaleX = 1.5f
        focusRing.scaleY = 1.5f
        focusRing.visibility = View.VISIBLE
        focusRing.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(200).withEndAction {
            focusRing.animate().alpha(0f).setStartDelay(700).setDuration(300).withEndAction {
                focusRing.visibility = View.GONE
            }.start()
        }.start()
    }

    // ---- Front / back camera ----

    private fun flipCamera() {
        if (recorder?.isCapturing == true) {
            Toast.makeText(this, "Stop recording first", Toast.LENGTH_SHORT).show()
            return
        }
        useFront = !useFront
        prefs.edit().putBoolean("front", useFront).apply()
        closeCamera()
        openCameraIfReady()
    }

    private fun modeTab(key: String, label: String, tip: String): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 12f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.letterSpacing = 0.06f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(12), dp(7), dp(12), dp(7))
        tv.tooltipText = tip
        tv.setOnClickListener { setCaptureMode(key) }
        return tv
    }

    private fun applyModeStyles() {
        if (!::modeViews.isInitialized) return
        for ((k, v) in modeViews) {
            val selected = k == captureMode
            v.setTextColor(if (selected) Color.WHITE else 0xCCFFFFFF.toInt())
            v.background = pill(if (selected) red else 0x66000000)
        }
        fixButton.text = if (previewFix == 0) "↻ Auto" else "↻ $previewFix°"
    }

    private fun setCaptureMode(key: String) {
        if (key == captureMode) return
        if (recorder?.isCapturing == true) {
            Toast.makeText(this, "Stop recording first", Toast.LENGTH_SHORT).show()
            return
        }
        if (key == "slomo" && usableModes.isNotEmpty() && CameraModes.slowMo(usableModes) == null) {
            Toast.makeText(this, "Slow motion isn't supported by this device's camera", Toast.LENGTH_LONG).show()
            return
        }
        captureMode = key
        prefs.edit().putString("capmode", key).apply()
        closeCamera()
        refreshLabels()
        openCameraIfReady()
    }

    private fun cyclePreviewFix() {
        previewFix = when (previewFix) { 0 -> 90; 90 -> 180; 180 -> 270; else -> 0 }
        prefs.edit().putInt("previewfix", previewFix).apply()
        applyModeStyles()
        configureTransform()
    }

    private fun allowedPreRolls(m: Mode): List<Int> =
        listOf(3, 5, 10).filter { m.bitRate / 8.0 * (it + 1) <= 150_000_000 }.ifEmpty { listOf(3) }

    private fun cyclePreRoll() {
        val m = mode ?: return
        if (recorder?.isCapturing == true) {
            Toast.makeText(this, "Stop recording first", Toast.LENGTH_SHORT).show()
            return
        }
        val opts = allowedPreRolls(m)
        preRollSec = opts.firstOrNull { it > preRollSec } ?: opts.first()
        prefs.edit().putInt("preroll", preRollSec).apply()
        recorder?.preRollUs = preRollSec * 1_000_000L
        refreshLabels()
        Toast.makeText(this, "Pre-roll: $preRollSec s (buffer refills in a moment)", Toast.LENGTH_SHORT).show()
    }

    private fun showModePicker() {
        if (recorder?.isCapturing == true) {
            Toast.makeText(this, "Stop recording first", Toast.LENGTH_SHORT).show()
            return
        }
        if (captureMode == "slomo") {
            Toast.makeText(this, "Slo-mo always uses the fastest frame rate your device allows", Toast.LENGTH_LONG).show()
            return
        }
        if (usableModes.isEmpty()) return
        val rec = recommended
        val maxMode = usableModes.first()
        val ordered = listOfNotNull(rec) + usableModes.filter { it.key != rec?.key }
        val labels = ordered.map {
            val tag = when {
                it.key == rec?.key -> "★ Recommended\n"
                it.key == maxMode.key -> "⚡ Maximum\n"
                else -> ""
            }
            tag + it.label
        }.toTypedArray()
        val checked = ordered.indexOfFirst { it.key == mode?.key }.coerceAtLeast(0)
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Recording quality")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                val picked = ordered[which]
                prefs.edit().putString("mode", if (picked.key == rec?.key) "auto" else picked.key).apply()
                dialog.dismiss()
                closeCamera()
                openCameraIfReady()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =========================================================================================
    // Capture
    // =========================================================================================

    private fun flashScreen() {
        flash.animate().cancel()
        flash.alpha = 0.55f
        flash.animate().alpha(0f).setDuration(220).setInterpolator(AccelerateInterpolator()).start()
    }

    private fun toggleCapture() {
        val rec = recorder
        if (rec == null || !sessionReady) {
            Toast.makeText(this, "Camera is still starting…", Toast.LENGTH_SHORT).show()
            return
        }
        if (rec.isCapturing) {
            finishCapture()
            return
        }
        val name = "CacheCam_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CacheCam")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return
        val pfd = contentResolver.openFileDescriptor(uri, "rw") ?: return
        val preUs = rec.startCapture(pfd.fileDescriptor, uprightRotation(), captureMode != "video")
        if (preUs >= 0) {
            pendingUri = uri
            pendingPfd = pfd
            captureStartElapsed = SystemClock.elapsedRealtime()
            capturePreRollMs = preUs / 1000
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED
            shutter.recording = true
            recBorder.visibility = View.VISIBLE
            recPulse = ObjectAnimator.ofFloat(recBorder, "alpha", 1f, 0.3f).apply {
                duration = 700
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                start()
            }
            refreshLabels()
            shutter.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            flashScreen()
        } else {
            pfd.close()
            contentResolver.delete(uri, null, null)
            Toast.makeText(this, "Buffer not ready yet, try again in a second", Toast.LENGTH_SHORT).show()
        }
    }

    private fun finishCapture() {
        val uri = pendingUri ?: return
        val totalSec = (SystemClock.elapsedRealtime() - captureStartElapsed + capturePreRollMs) / 1000
        recorder?.stopCapture()
        try { pendingPfd?.close() } catch (_: Exception) { }
        val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
        contentResolver.update(uri, done, null, null)
        pendingUri = null
        pendingPfd = null

        recPulse?.cancel()
        recPulse = null
        recBorder.alpha = 1f
        recBorder.visibility = View.GONE
        shutter.recording = false
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        refreshLabels()
        shutter.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        Toast.makeText(this, "Saved ${fmtTime(totalSec)} clip to Movies/CacheCam", Toast.LENGTH_LONG).show()
    }
}

package com.example.cachecam

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTimestamp
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.os.Bundle
import android.os.SystemClock
import android.view.Surface
import java.io.FileDescriptor
import java.nio.ByteBuffer
import java.util.ArrayDeque

/**
 * Encodes camera frames continuously and keeps only the most recent [preRollUs] microseconds
 * of *encoded* samples in memory (a ring buffer).
 *
 * When [startCapture] is called, the buffered samples (starting at a keyframe) are written to a
 * new MP4 first, then every new sample is appended until [stopCapture].
 *
 * The ring always starts at a keyframe (1 s interval), so it holds between preRoll and
 * preRoll + 1 s of video, guaranteeing at least [preRollUs] of history.
 */
class CacheRecorder(
    private val mode: Mode,
    @Volatile var preRollUs: Long = 3_000_000L,
    /** Timestamp stretch for slow motion: 4 means the clip plays back 4x slower. */
    private val slow: Int = 1,
    /** Record the microphone too (AAC), buffered alongside the video pre-roll. */
    private val withAudio: Boolean = false,
    /** True when the camera timestamps use the boot clock (else the monotonic clock). */
    private val realtimeClock: Boolean = false,
) {
    private class Sample(val data: ByteArray, val ptsUs: Long, val flags: Int) {
        val isKey: Boolean get() = flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
    }

    private lateinit var codec: MediaCodec
    lateinit var inputSurface: Surface
        private set

    private val lock = Any()
    private val ring = ArrayDeque<Sample>()
    private var outputFormat: MediaFormat? = null
    private var muxer: MediaMuxer? = null
    private var track = -1
    private var basePts = 0L
    private var waitKey = false   // normal-video mode: skip frames until the first keyframe

    // ---- Audio ----
    private var audioRecord: AudioRecord? = null
    private var audioCodec: MediaCodec? = null
    private var audioFormat: MediaFormat? = null
    private var audioTrack = -1
    private val audioRing = ArrayDeque<Sample>()
    private var audioThread: Thread? = null

    /** True when the microphone is actually recording. */
    @Volatile var hasAudio = false
        private set

    @Volatile private var running = false
    private var drainThread: Thread? = null

    val isCapturing: Boolean get() = synchronized(lock) { muxer != null }

    /** How much footage (in microseconds) is currently waiting in the pre-roll buffer. */
    fun bufferedUs(): Long = synchronized(lock) {
        val first = ring.peekFirst() ?: return 0L
        val last = ring.peekLast() ?: return 0L
        last.ptsUs - first.ptsUs
    }

    fun start() {
        val format = MediaFormat.createVideoFormat(mode.mime, mode.size.width, mode.size.height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, mode.bitRate)
            setInteger(MediaFormat.KEY_FRAME_RATE, mode.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            setInteger(MediaFormat.KEY_PRIORITY, 0)               // real-time
            setInteger(MediaFormat.KEY_OPERATING_RATE, mode.fps)  // run the encoder at full speed
        }
        codec = MediaCodec.createByCodecName(mode.codecName)
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = codec.createInputSurface()
            codec.start()
        } catch (e: Exception) {
            codec.release()
            throw e
        }
        running = true
        drainThread = Thread({ drainLoop() }, "cache-drain").also { it.start() }
        if (withAudio) startAudio()
    }

    private fun drainLoop() {
        val info = MediaCodec.BufferInfo()
        while (running) {
            val index = try {
                codec.dequeueOutputBuffer(info, 10_000)
            } catch (e: IllegalStateException) {
                break
            }
            when {
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> synchronized(lock) {
                    outputFormat = codec.outputFormat
                }
                index >= 0 -> {
                    val buf = codec.getOutputBuffer(index)
                    val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                    if (buf != null && info.size > 0 && !isConfig) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val bytes = ByteArray(info.size)
                        buf.get(bytes)
                        onSample(Sample(bytes, info.presentationTimeUs, info.flags))
                    }
                    codec.releaseOutputBuffer(index, false)
                }
            }
        }
    }

    private fun onSample(s: Sample) = synchronized(lock) {
        val m = muxer
        if (m != null) {
            if (waitKey) {
                if (!s.isKey) return@synchronized
                waitKey = false
                basePts = s.ptsUs
            }
            writeSample(m, s)
        } else {
            ring.addLast(s)
            trim(s.ptsUs)
        }
    }

    /** Drop whole GOPs from the front while the *next* keyframe is still old enough. */
    private fun trim(newestPts: Long) {
        val keep = preRollUs
        while (true) {
            var seenFirst = false
            var secondKey: Sample? = null
            for (x in ring) {
                if (x.isKey) {
                    if (seenFirst) { secondKey = x; break } else seenFirst = true
                }
            }
            if (secondKey == null || secondKey.ptsUs > newestPts - keep) return
            while (ring.peekFirst() !== secondKey) ring.removeFirst()
        }
    }

    private fun writeSample(m: MediaMuxer, s: Sample) {
        val info = MediaCodec.BufferInfo()
        info.set(0, s.data.size, (s.ptsUs - basePts).coerceAtLeast(0) * slow, s.flags)
        m.writeSampleData(track, ByteBuffer.wrap(s.data), info)
    }

    /**
     * Writes the buffered pre-roll into [fd] and keeps recording until [stopCapture].
     * [orientationDeg] is the rotation (0/90/180/270) players must apply so the video is upright.
     * Returns the length of pre-roll footage written in microseconds, or -1 if not ready yet.
     */
    fun startCapture(fd: FileDescriptor, orientationDeg: Int, withPreRoll: Boolean = true): Long = synchronized(lock) {
        if (muxer != null) return -1L
        val fmt = outputFormat ?: return -1L
        val first = ring.peekFirst()
        val last = ring.peekLast()
        if (withPreRoll && (first == null || last == null)) return -1L
        val m = MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        m.setOrientationHint(orientationDeg)
        track = m.addTrack(fmt)
        val af = audioFormat
        audioTrack = if (hasAudio && af != null) m.addTrack(af) else -1
        m.start()
        var pre = 0L
        if (withPreRoll && first != null && last != null) {
            basePts = first.ptsUs
            for (s in ring) writeSample(m, s)
            if (audioTrack >= 0) for (a in audioRing) if (a.ptsUs >= basePts) writeAudio(m, a)
            pre = last.ptsUs - first.ptsUs
            waitKey = false
        } else {
            // Normal video: start from the next keyframe, and ask the encoder for one right now.
            waitKey = true
            try {
                codec.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
            } catch (_: Exception) { }
        }
        ring.clear()
        audioRing.clear()
        muxer = m
        pre
    }

    fun stopCapture() = synchronized(lock) {
        val m = muxer ?: return@synchronized
        muxer = null
        audioTrack = -1
        waitKey = false
        try { m.stop() } catch (_: Exception) { }
        m.release()
    }

    // ---- Audio pipeline: mic -> AAC -> ring buffer (and straight into the file while capturing) ----

    @SuppressLint("MissingPermission")
    private fun startAudio() {
        val rate = 44100
        try {
            val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuf <= 0) return
            var ar: AudioRecord? = null
            for (source in listOf(MediaRecorder.AudioSource.CAMCORDER, MediaRecorder.AudioSource.MIC)) {
                val candidate = AudioRecord(
                    source, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 4
                )
                if (candidate.state == AudioRecord.STATE_INITIALIZED) { ar = candidate; break }
                candidate.release()
            }
            if (ar == null) return
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            val ac = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            ac.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            ac.start()
            ar.startRecording()
            audioRecord = ar
            audioCodec = ac
            hasAudio = true
            val recorder = ar
            audioThread = Thread({ audioLoop(recorder, ac, rate) }, "cache-audio").also { it.start() }
        } catch (e: Exception) {
            hasAudio = false
        }
    }

    /** Time (us, on the same clock as the camera frames) of the very first audio frame. */
    private fun audioAnchorUs(ar: AudioRecord, rate: Int, firstFrames: Int): Long {
        val ts = AudioTimestamp()
        val base = if (realtimeClock) AudioTimestamp.TIMEBASE_BOOTTIME else AudioTimestamp.TIMEBASE_MONOTONIC
        if (ar.getTimestamp(ts, base) == AudioRecord.SUCCESS) {
            return ts.nanoTime / 1000 - ts.framePosition * 1_000_000L / rate
        }
        val nowUs = (if (realtimeClock) SystemClock.elapsedRealtimeNanos() else System.nanoTime()) / 1000
        return nowUs - firstFrames * 1_000_000L / rate
    }

    private fun audioLoop(ar: AudioRecord, ac: MediaCodec, rate: Int) {
        val pcm = ByteArray(4096)
        val info = MediaCodec.BufferInfo()
        var frames = 0L
        var anchorUs = Long.MIN_VALUE
        try {
            while (running) {
                val n = ar.read(pcm, 0, pcm.size)
                if (n < 0) break
                if (n == 0) continue
                if (anchorUs == Long.MIN_VALUE) anchorUs = audioAnchorUs(ar, rate, n / 2)
                val chunkPts = anchorUs + frames * 1_000_000L / rate
                frames += n / 2
                var off = 0
                while (off < n && running) {
                    val i = ac.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val ib = ac.getInputBuffer(i)!!
                        ib.clear()
                        val len = minOf(n - off, ib.remaining())
                        ib.put(pcm, off, len)
                        ac.queueInputBuffer(i, 0, len, chunkPts + (off / 2) * 1_000_000L / rate, 0)
                        off += len
                    }
                    drainAudio(ac, info)
                }
                drainAudio(ac, info)
            }
        } catch (e: Exception) {
            // codec/recorder released while running
        }
    }

    private fun drainAudio(ac: MediaCodec, info: MediaCodec.BufferInfo) {
        while (true) {
            val idx = ac.dequeueOutputBuffer(info, 0)
            when {
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> synchronized(lock) {
                    audioFormat = ac.outputFormat
                }
                idx >= 0 -> {
                    val buf = ac.getOutputBuffer(idx)
                    val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                    if (buf != null && info.size > 0 && !isConfig) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val bytes = ByteArray(info.size)
                        buf.get(bytes)
                        onAudioSample(Sample(bytes, info.presentationTimeUs, info.flags))
                    }
                    ac.releaseOutputBuffer(idx, false)
                }
                else -> return
            }
        }
    }

    private fun onAudioSample(s: Sample) = synchronized(lock) {
        val m = muxer
        if (m != null && audioTrack >= 0) {
            if (!waitKey && s.ptsUs >= basePts) writeAudio(m, s)
        } else {
            audioRing.addLast(s)
            val cutoff = s.ptsUs - preRollUs - 2_000_000L
            while (audioRing.isNotEmpty() && audioRing.peekFirst()!!.ptsUs < cutoff) audioRing.removeFirst()
        }
    }

    private fun writeAudio(m: MediaMuxer, s: Sample) {
        val info = MediaCodec.BufferInfo()
        info.set(0, s.data.size, (s.ptsUs - basePts).coerceAtLeast(0), s.flags)
        m.writeSampleData(audioTrack, ByteBuffer.wrap(s.data), info)
    }

    fun release() {
        stopCapture()
        running = false
        drainThread?.join(500)
        audioThread?.join(500)
        try { audioRecord?.stop() } catch (_: Exception) { }
        try { audioRecord?.release() } catch (_: Exception) { }
        try { audioCodec?.stop() } catch (_: Exception) { }
        try { audioCodec?.release() } catch (_: Exception) { }
        try { codec.stop() } catch (_: Exception) { }
        codec.release()
        try { inputSurface.release() } catch (_: Exception) { }
    }
}

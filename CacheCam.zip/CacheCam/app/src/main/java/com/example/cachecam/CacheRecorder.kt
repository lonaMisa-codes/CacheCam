package com.example.cachecam

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.view.Surface
import java.io.FileDescriptor
import java.nio.ByteBuffer
import java.util.ArrayDeque

/**
 * Encodes camera frames continuously and keeps only the most recent [preRollUs] microseconds
 * of *encoded* samples in memory (a ring buffer).
 *
 * When [startCapture] is called, the buffered samples (starting at a keyframe) are written to a
 * new MP4 first, then every new sample is appended until [stopCapture].
 *
 * The ring always starts at a keyframe (1 s interval), so it holds between preRoll and
 * preRoll + 1 s of video, guaranteeing at least [preRollUs] of history.
 */
class CacheRecorder(
    private val mode: Mode,
    @Volatile var preRollUs: Long = 3_000_000L,
) {
    private class Sample(val data: ByteArray, val ptsUs: Long, val flags: Int) {
        val isKey: Boolean get() = flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
    }

    private lateinit var codec: MediaCodec
    lateinit var inputSurface: Surface
        private set

    private val lock = Any()
    private val ring = ArrayDeque<Sample>()
    private var outputFormat: MediaFormat? = null
    private var muxer: MediaMuxer? = null
    private var track = -1
    private var basePts = 0L

    @Volatile private var running = false
    private var drainThread: Thread? = null

    val isCapturing: Boolean get() = synchronized(lock) { muxer != null }

    /** How much footage (in microseconds) is currently waiting in the pre-roll buffer. */
    fun bufferedUs(): Long = synchronized(lock) {
        val first = ring.peekFirst() ?: return 0L
        val last = ring.peekLast() ?: return 0L
        last.ptsUs - first.ptsUs
    }

    fun start() {
        val format = MediaFormat.createVideoFormat(mode.mime, mode.size.width, mode.size.height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, mode.bitRate)
            setInteger(MediaFormat.KEY_FRAME_RATE, mode.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            setInteger(MediaFormat.KEY_PRIORITY, 0)               // real-time
            setInteger(MediaFormat.KEY_OPERATING_RATE, mode.fps)  // run the encoder at full speed
        }
        codec = MediaCodec.createByCodecName(mode.codecName)
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = codec.createInputSurface()
            codec.start()
        } catch (e: Exception) {
            codec.release()
            throw e
        }
        running = true
        drainThread = Thread({ drainLoop() }, "cache-drain").also { it.start() }
    }

    private fun drainLoop() {
        val info = MediaCodec.BufferInfo()
        while (running) {
            val index = try {
                codec.dequeueOutputBuffer(info, 10_000)
            } catch (e: IllegalStateException) {
                break
            }
            when {
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> synchronized(lock) {
                    outputFormat = codec.outputFormat
                }
                index >= 0 -> {
                    val buf = codec.getOutputBuffer(index)
                    val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                    if (buf != null && info.size > 0 && !isConfig) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val bytes = ByteArray(info.size)
                        buf.get(bytes)
                        onSample(Sample(bytes, info.presentationTimeUs, info.flags))
                    }
                    codec.releaseOutputBuffer(index, false)
                }
            }
        }
    }

    private fun onSample(s: Sample) = synchronized(lock) {
        val m = muxer
        if (m != null) {
            writeSample(m, s)
        } else {
            ring.addLast(s)
            trim(s.ptsUs)
        }
    }

    /** Drop whole GOPs from the front while the *next* keyframe is still old enough. */
    private fun trim(newestPts: Long) {
        val keep = preRollUs
        while (true) {
            var seenFirst = false
            var secondKey: Sample? = null
            for (x in ring) {
                if (x.isKey) {
                    if (seenFirst) { secondKey = x; break } else seenFirst = true
                }
            }
            if (secondKey == null || secondKey.ptsUs > newestPts - keep) return
            while (ring.peekFirst() !== secondKey) ring.removeFirst()
        }
    }

    private fun writeSample(m: MediaMuxer, s: Sample) {
        val info = MediaCodec.BufferInfo()
        info.set(0, s.data.size, (s.ptsUs - basePts).coerceAtLeast(0), s.flags)
        m.writeSampleData(track, ByteBuffer.wrap(s.data), info)
    }

    /**
     * Writes the buffered pre-roll into [fd] and keeps recording until [stopCapture].
     * [orientationDeg] is the rotation (0/90/180/270) players must apply so the video is upright.
     * Returns the length of pre-roll footage written in microseconds, or -1 if not ready yet.
     */
    fun startCapture(fd: FileDescriptor, orientationDeg: Int): Long = synchronized(lock) {
        if (muxer != null) return -1L
        val fmt = outputFormat ?: return -1L
        val first = ring.peekFirst() ?: return -1L
        val last = ring.peekLast() ?: return -1L
        val m = MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        m.setOrientationHint(orientationDeg)
        track = m.addTrack(fmt)
        m.start()
        basePts = first.ptsUs
        for (s in ring) writeSample(m, s)
        ring.clear()
        muxer = m
        last.ptsUs - first.ptsUs
    }

    fun stopCapture() = synchronized(lock) {
        val m = muxer ?: return@synchronized
        muxer = null
        try { m.stop() } catch (_: Exception) { }
        m.release()
    }

    fun release() {
        stopCapture()
        running = false
        drainThread?.join(500)
        try { codec.stop() } catch (_: Exception) { }
        codec.release()
        try { inputSurface.release() } catch (_: Exception) { }
    }
}
